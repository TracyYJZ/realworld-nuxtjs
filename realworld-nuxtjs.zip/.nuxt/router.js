import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _67b27994 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _2fc905c9 = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _6ce00882 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _7ea6d87f = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _31176fe6 = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _5be39fd7 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _65711bcc = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _67b27994,
    children: [{
      path: "",
      component: _2fc905c9,
      name: "home"
    }, {
      path: "/login",
      component: _6ce00882,
      name: "login"
    }, {
      path: "/register",
      component: _6ce00882,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _7ea6d87f,
      name: "profile"
    }, {
      path: "/settings",
      component: _31176fe6,
      name: "settings"
    }, {
      path: "/editor/:slug?",
      component: _5be39fd7,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _65711bcc,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
